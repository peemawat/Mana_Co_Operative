using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;

namespace ManaApi.Models
{
    public class User
    {
        
        [BsonId]
        [BsonRepresentation(BsonType.String)]
        public string _id { get; set; }

        [BsonElement("Name")]
        public string Name { get; set; }

        public string Email { get; set; }

        public string  Username { get; set; }

        public string Password { get; set; }
        

    }
}